This EEZ comes from work done by Anna Serdynska.  It is a shapefile for the EEZ of all of Canada:

Advantages
1:  It has the Canadian version of the EEZ around grey zone
2:  It is a small file and works quickly
3:  It is a proper GIS shapefile
4:  I know where it comes from https://www.nrcan.gc.ca/earth-sciences/geography/topographic-information

Disadvantages
1:  Is limited to Canadian waters


# Note that the project this was done under is found here.
Y:\INSHORE SCALLOP\Inshore Scallop Fishing Area Map